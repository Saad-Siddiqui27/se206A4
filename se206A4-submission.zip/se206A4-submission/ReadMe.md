
#### The target audience for this Application is children.


##### To run the Application:
To run the project use the Linux-beta version on the Lab computers.
go into the folder where the following jar is located(JavaFXApp.jar) and open terminal there. Run the following command on the terminal: java -jar JavaFXApp.jar.
if the jar does not have executable permissions then first run the command chmod +x on the terminal to give it executable permissions.

Do not delete any of the files or directories. all files and directories are essential for the effective running of application.

The ffmpeg used in this project is the version 4.

##### usability instructions:

first create an Audio, then go back to the main screen to create a creation of that audio. And then you can play that creation and play a quiz game.



##### background Music:

The back ground music is used under the following copyrights.  

Unify by Snowflake (c) copyright 2019 Licensed under a Creative Commons Attribution (3.0) license. http://dig.ccmixter.org/files/snowflake/59709 Ft: Apoxode

